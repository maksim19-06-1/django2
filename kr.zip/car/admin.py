from django.contrib import admin
from .models import Manufacturer, Model
admin.site.register(Manufacturer)
admin.site.register(Model)
# Register your models here.
