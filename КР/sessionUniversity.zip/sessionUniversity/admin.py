from django.contrib import admin
from .models import Exam, Student, Subject
admin.site.register(Exam)
admin.site.register(Student)
admin.site.register(Subject)
# Register your models here.
